function hello(name) {
    alert("Hello " + name + "!");
}

hello("Flier Lu");
