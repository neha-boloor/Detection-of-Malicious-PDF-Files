.. _1minute:

One Minute Tutorial
==========================

.. toctree::
   :maxdepth: 2